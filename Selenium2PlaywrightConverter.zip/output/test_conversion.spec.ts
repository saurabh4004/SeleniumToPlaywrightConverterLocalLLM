Here is the converted TypeScript code:

import { test, expect } from '@playwright/test';

test('print title', async ({ page }) => {
  const url = 'https://www.google.com';
  await page.goto(url);
  const title = await page.title();
  console.log(title);
});

Note that the converted code uses Playwright's `page` object to navigate to the URL, retrieve the title, and log it to the console. The `test` function is also imported from `@playwright/test`, which is used to define a test case.

Also note that this code does not use any of the `WebDriver` class's methods, such as `get()`, `findElement()`, or `quit()`. These methods are replaced by Playwright's own functions for navigating to URLs and interacting with web pages.